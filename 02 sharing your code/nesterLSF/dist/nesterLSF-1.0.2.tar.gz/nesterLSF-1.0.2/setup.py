from distutils.core import setup

setup(
	name = 'nesterLSF',
	version = '1.0.2',
	py_modules = ['nesterLSF']
)
