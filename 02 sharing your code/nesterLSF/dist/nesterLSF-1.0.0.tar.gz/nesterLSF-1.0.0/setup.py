from distutils.core import setup

setup(
	name = 'nesterLSF',
	version = '1.0.0',
	py_modules = ['nesterLSF'],
	author = 'lsf',
	author_email = 'lsfapps@gmail.com',
	url = 'http://www.google.com',
	description = 'A simple printer of nested lists.'
)
