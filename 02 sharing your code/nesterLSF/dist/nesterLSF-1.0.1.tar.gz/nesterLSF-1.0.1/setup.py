from distutils.core import setup

setup(
	name = 'nesterLSF',
	version = '1.0.1',
	py_modules = ['nesterLSF']
)
