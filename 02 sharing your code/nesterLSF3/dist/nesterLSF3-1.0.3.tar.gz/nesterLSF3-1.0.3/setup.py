from setuptools import setup

setup(
	name = 'nesterLSF3',
	version = '1.0.3',
	py_modules = ['nesterLSF3']
)
