from distutils.core import setup

setup(
	name = 'nester',
	version = '1.0.0',
	py_modules = ['nester'],
	author = 'lsf',
	author_email = 'lsfapps@gmail.com',
	url = 'http://www.google.com',
	description = 'A simple printer of nested lists.'
)
