from setuptools import setup

setup(
	name = 'nesterLSF3',
	version = '1.0.5',
	py_modules = ['nesterLSF3']
)
